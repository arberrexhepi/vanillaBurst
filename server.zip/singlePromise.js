function singlePromise(renderSchema, passedFunction, serverResult, burstOrigin, originBurst) {
    console.log("single promis for function " + JSON.stringify(window.passedFunction));
    renderSchema = window.renderSchema;
    serverResult = window.serverResult;
    passedFunction = window.passedFunction;
    burstOrigin = window.burstOrigin;
    originBurst = window.originBurst;
    let originBurstUrl;

    if (passedFunction) {
        var customFunction = passedFunction;
        var customFunctionName = customFunction.functionFile;

        var baseCustomFunctionDirectory = baseUrl;
        var customFunctionDirectory = customFunction.dir;
        var customFunctionUrl = baseCustomFunctionDirectory + customFunctionDirectory + customFunctionName + '.js';
    }

    console.log(customFunction);

    if (customFunctionName && customFunction.render == "burst") {
        function addScriptToHead(url, originBurstUrl) {
            // Check if the script tag with the given URL already exists
            const existingScripts = document.querySelectorAll('head script');
            for (let i = 0; i < existingScripts.length; i++) {
                if (existingScripts[i] === customFunctionName && window.originBurst[customFunctionName].burst === false) {
                    originBurstUrl = true;
                } else {
                    originBurstUrl = false;
                }

                if (existingScripts[i].src === url || originBurstUrl === true) {
                    // Script already exists; no need to add it again
                    return;
                }
            }

            // Create and append the script tag to the head
            const script = document.createElement('script');
            script.type = 'text/javascript';
            script.src = url;
            script.id = customFunctionName;
            document.head.appendChild(script);
        }

        function readyCustomFunctions(customFunctionUrl, originBurstUrl) {
            // Remove the loader once before loading the scripts
            return new Promise((resolve, reject) => {
                let script = document.createElement('script');
                script.src = customFunctionUrl;

                script.onload = () => {
                    window.preloaderAnimation();
                    console.log(customFunctionUrl);

                    // Add the successfully loaded script to the head
                    addScriptToHead(customFunctionUrl, originBurstUrl);

                    resolve(renderSchema);
                };

                script.onerror = () => {
                    reject(new Error(`Failed to load script at ${customFunctionUrl}`));
                };

                document.head.appendChild(script);
            });
        }

        // Call those functions
        readyCustomFunctions(customFunctionUrl, customFunctionName, originBurstUrl)
            .then(() => {
                // async function to execute the loaded function
                async function executeFunction() {
                    if (typeof window[customFunctionName] === 'function') {
                        // If the function returns a promise, you can await it
                        if (serverResult) {
                            console.log(JSON.stringify(serverResult));
                            window.burstOrigin = burstOrigin;
                            window.serverResult = serverResult;
                            await window[customFunctionName](renderSchema, passedFunction, serverResult, burstOrigin, originBurst);
                        } else {
                            await window[customFunctionName](renderSchema, passedFunction, burstOrigin, originBurst);
                        }
                        window.removeLoader();
                    } else {
                        console.warn(`Function ${customFunctionName} is not defined on the window object`);
                    }
                }

                executeFunction();
            })
            .catch(error => {
                console.error('Error loading script:', error);
            });
    }
}

window.singlePromise = singlePromise;
