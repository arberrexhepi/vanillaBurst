
  // window.routeParts = {
//   'shopLocation': false,  
      //this calls file routes/parts/shopLocation.js and false means it is not a View so it does not build a top level object. 
      //it does however make it available to be called, see window.navPackage
//   'shop': ['navPackage, navPackage2'], //the array iterates references of arrays of functions for the result of the schema objects in those files, can have multipl array references, string comma separated
//   'cart': ['navPackage'],
//   'product': null, //null means this part is loaded without any extra schema parts
//   'profile': null,
//   'orders': null,
// };

  // window.navPackage2 = [
  //   'shopLocation2Config'
  //  ]

  
  $.ajaxSetup({
      cache: true,
      async: true
  });

  window.appRoute = 'shop';
  baseUrlIcons = "../wp-content/themes/classic-pizza/assets/icons/";
  baseUrlStyles = "../wp-content/themes/classic-pizza/styles/";


  window.navPackage = [
   'shopLocationConfig'
  ]

    window.schemaParts = {
      'shopLocation':false,
      'shop': ['navPackage'], // as tring of array variable names
      'cart': ['navPackage'],
      'product':['navPackage'],
      'profile':['navPackage'],
      'orders':['navPackage'],
    };



    //usage in ie shopRequest.js where if it's string you simply add it as a variable window.modalPackage or array spread as ...window.modalPackage
    window.modalPackage = ['shoplocationRequest'];

    //window.modalPackage = 'shopLocation2Config';